#include <stdio.h>
#ifndef config_h
#define config_h

#define _WINSOCKAPI_

/* define class name and unique id */
#define MODEL_IDENTIFIER CARLABridge
#define INSTANTIATION_TOKEN "{1-2-3-4-5}"

#define CO_SIMULATION

// #define pipeForLidarPC
// #define pipeForCamera


/* define model size */
#define NX 0
#define NZ 0


#define SET_FLOAT64
#define EVENT_UPDATE
#define SET_INT32
#define GET_INT32

#define FIXED_SOLVER_STEP  0.04
#define DEFAULT_STOP_TIME 999

// #define CLEAN_UP


typedef enum {
    vr_CARLAin__desired_speed=0,
    vr_CARLAin__desired_steering=1,
    vr_CARLAout__act_speed=2,
    vr_CARLAin__scenario=3,
    vr_CARLAin__toggle_display=4,
    vr_CARLAin__desired_brake=5,
    vr_CARLAout__park_coordinate_x=6,
	vr_CARLAout__act_steering=7,
	vr_CARLAout__act_pos_x=8,
	vr_CARLAout__act_pos_y=9,
	vr_CARLAout__act_yaw_angle=10,
	vr_CARLAout__act_lat_acceleration=11,
	vr_CARLAout__current_speed_limit=12,
	vr_CARLAout__park_coordinate_y=13,
	vr_CARLAin__operation_mode=14,
	vr_CARLAin__toggle_view=15,
    vr_CARLAin__toggle_special_lights=16,
    vr_CARLAin__auto_pilot=17,
    vr_CARLAout__act_pos_z=18,
    vr_CARLAout__act_pitch_angle=19,
    vr_CARLAout__act_roll_angle=20,
    vr_CARLAout__act_yaw_rate=21,
    vr_CARLAout__act_throttle=22,
    vr_CARLAout__act_brake=23,
    vr_CARLAout__act_long_acceleration=24,
    vr_CARLAin__reset_scene=25,
    vr_CARLAin__weather=26,
    vr_CARLAout__park_coordinate_z=27,
    vr_CARLAout__mini_lidar_front_x=28,
    vr_CARLAout__mini_lidar_front_y=29,
    vr_CARLAin__DisplayColor_r=30,
    vr_CARLAin__DisplayColor_g=31,
    vr_CARLAin__DisplayColor_b=32,
    vr_CARLAin__DisplayText_char01=33,
    vr_CARLAin__DisplayText_char02=34,
    vr_CARLAin__DisplayText_char03=35,
    vr_CARLAin__DisplayText_char04=36,
    vr_CARLAin__DisplayText_char05=37,
    vr_CARLAin__DisplayText_char06=38,
    vr_CARLAin__DisplayText_char07=39,
    vr_CARLAin__DisplayText_char08=40,
    vr_CARLAin__DisplayText_char09=41,
    vr_CARLAin__DisplayText_char10=42,
    vr_CARLAin__DisplayText_char11=43,
    vr_CARLAin__DisplayText_char12=44,
    vr_CARLAin__DisplayText_char13=45,
    vr_CARLAin__DisplayText_char14=46,
    vr_CARLAin__DisplayText_char15=47,
    vr_CARLAin__DisplayText_char16=48,
    vr_CARLAin__toggle_buzzer=49,
    vr_CARLAin__DooropenStatus_FL=50,
    vr_CARLAin__DooropenStatus_FR=51,
    vr_CARLAin__DooropenStatus_RL=52,
    vr_CARLAin__DooropenStatus_RR=53,
    vr_CARLAout__DooropenStatus_FL=54,
    vr_CARLAout__DooropenStatus_FR=55,
    vr_CARLAout__DooropenStatus_RL=56,
    vr_CARLAout__DooropenStatus_RR=57,
    vr_CARLAin__Headlight_Lowbeam=58
} ValueReference;

typedef struct {
    double CARLAin__desired_speed;
    double CARLAin__desired_steering;
    double CARLAout__act_speed;
    int CARLAin__scenario;
    int CARLAin__toggle_display;
    double CARLAin__desired_brake;
    // CARLAout__lidar_points_primary[25535];
    double CARLAout__park_coordinate_x;
	double CARLAout__act_steering;
	double CARLAout__act_pos_x;
	double CARLAout__act_pos_y;
	double CARLAout__act_yaw_angle;
	double CARLAout__act_lat_acceleration;
	double CARLAout__current_speed_limit;
	// char CARLAout__park_coordinates[25535];
    double CARLAout__park_coordinate_y;
	int CARLAin__operation_mode;
	int CARLAin__toggle_view;
    int CARLAin__toggle_special_lights;
    int CARLAin__auto_pilot;
    double CARLAout__act_pos_z;
    double CARLAout__act_pitch_angle;
    double CARLAout__act_roll_angle;
    double CARLAout__act_yaw_rate;
    double CARLAout__act_throttle;
    double CARLAout__act_brake;
    double CARLAout__act_long_acceleration;
    int CARLAin__reset_scene;
    int CARLAin__weather;
    // char CARLAout__lidar_pc_front_secondary[25535];
    double CARLAout__park_coordinate_z;
    double CARLAout__mini_lidar_front_x;
    double CARLAout__mini_lidar_front_y;
    // variables for text display
    int CARLAin__DisplayColor_r;
    int CARLAin__DisplayColor_g;
    int CARLAin__DisplayColor_b;
    int CARLAin__DisplayText_char01;
    int CARLAin__DisplayText_char02;
    int CARLAin__DisplayText_char03;
    int CARLAin__DisplayText_char04;
    int CARLAin__DisplayText_char05;
    int CARLAin__DisplayText_char06;
    int CARLAin__DisplayText_char07;
    int CARLAin__DisplayText_char08;
    int CARLAin__DisplayText_char09;
    int CARLAin__DisplayText_char10;
    int CARLAin__DisplayText_char11;
    int CARLAin__DisplayText_char12;
    int CARLAin__DisplayText_char13;
    int CARLAin__DisplayText_char14;
    int CARLAin__DisplayText_char15;
    int CARLAin__DisplayText_char16;
    int CARLAin__toggle_buzzer;
    int CARLAin__DooropenStatus_FL;
    int CARLAin__DooropenStatus_FR;
    int CARLAin__DooropenStatus_RL;
    int CARLAin__DooropenStatus_RR;
    int CARLAout__DooropenStatus_FL;
    int CARLAout__DooropenStatus_FR;
    int CARLAout__DooropenStatus_RL;
    int CARLAout__DooropenStatus_RR;
    int CARLAin__Headlight_Lowbeam;
} ModelData;

/* Workaround when using VS MSVC compiler: struct to resolve timeval error by include <python.h>*/
// struct timeval {
    // long tv_sec;    /* seconds */
    // long tv_usec;   /* microseconds */
// };


#endif /* config_h */
