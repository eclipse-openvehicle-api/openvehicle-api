"""
***********************************************************************
* File Name   : keyboard_control.py
* Description : Integration of CARLA simulator features for demonstrating VAPI features
*
* Based on    : CARLA Simulator (https://github.com/carla-simulator/carla)
* License     : code are taken from CARLA, which is licensed under the MIT License.
*               See https://github.com/carla-simulator/carla/blob/master/LICENSE for details.
*
*************************************************************************
"""

import pygame
from pygame.locals import (
    RLEACCEL,
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
    KMOD_CTRL,
    KMOD_SHIFT,
    K_0,
    K_9,
    K_BACKQUOTE,
    K_BACKSPACE,
    K_COMMA,
    K_F1,
    K_PERIOD,
    K_SLASH,
    K_SPACE,
    K_TAB,
    K_MINUS,
    K_EQUALS,
    K_a,
    K_b,
    K_c,
    K_d,
    K_f,
    K_g,
    K_h,
    K_i,
    K_l,
    K_m,
    K_n,
    K_o,
    K_p,
    K_q,
    K_r,
    K_s,
    K_t,
    K_v,
    K_w,
    K_x,
    K_z
)
import carla


class ManualControl():
    def __init__(self, vehicle, use_ackermann, onExit, vehicle_lights):
        self.use_ackermann = use_ackermann
        self._ackermann_reverse = 1

        self.door_open_state = False
        self.ego = vehicle

        self.exitevent = onExit

        self.vehicleControl = carla.VehicleControl()
        self._ackermann_control = carla.VehicleAckermannControl()
        self._lights = vehicle_lights

        self._steer_cache = 0.0

    def parse_events(self, clock, status_speciallights):
        if isinstance(self.vehicleControl, carla.VehicleControl):
            current_lights = self._lights
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # * Stop Simulation * #
                if self.use_ackermann:
                    self.vehicleControl = self.ego.get_control()
                    return self.exitevent(), carla.VehicleLightState.NONE, self._ackermann_control
                else:
                    return self.exitevent(), carla.VehicleLightState.NONE, self.vehicleControl
            #
            elif event.type == pygame.KEYUP:
                if self._is_quit_shortcut(event.key):
                    # * Stop Simulation * #
                    if self.use_ackermann:
                        self.vehicleControl = self.ego.get_control()
                        return self.exitevent(), carla.VehicleLightState.NONE, self._ackermann_control
                    else:
                        return self.exitevent(), carla.VehicleLightState.NONE, self.vehicleControl
                #
                elif event.key == K_o:
                    try:
                        if self.door_open_state:
                            # Closing Doors
                            self.ego.close_door(carla.VehicleDoor.All)
                            self.door_open_state = False
                            current_lights ^= carla.VehicleLightState.Interior
                        else:
                            # Opening doors
                            self.ego.open_door(carla.VehicleDoor.All)
                            self.door_open_state = True
                            current_lights ^= carla.VehicleLightState.Interior
                    except Exception:
                        print('Door operation not available for the selected vehicle.')

                if isinstance(self.vehicleControl, carla.VehicleControl):
                    if event.key == K_f:
                        # Toggle ackermann controller
                        self.use_ackermann = not self.use_ackermann

                    if event.key == K_r:
                        if not self.use_ackermann:
                            self.vehicleControl.reverse = not self.vehicleControl.reverse
                        else:
                            self._ackermann_reverse *= -1
                            # Reset ackermann control
                            self._ackermann_control = carla.VehicleAckermannControl()

                    if event.key == K_q:
                        if not self.use_ackermann:
                            self.vehicleControl.gear = 1 if self.vehicleControl.reverse else -1
                        else:
                            self._ackermann_reverse *= -1
                            # Reset ackermann control
                            self._ackermann_control = carla.VehicleAckermannControl()

                    elif event.key == K_m:
                        self.vehicleControl.manual_gear_shift = not self.vehicleControl.manual_gear_shift
                        self.vehicleControl.gear = self.ego.get_control().gear
                    #
                    elif self.vehicleControl.manual_gear_shift and event.key == K_COMMA:
                        self.vehicleControl.gear = max(-1, self.vehicleControl.gear - 1)
                    elif self.vehicleControl.manual_gear_shift and event.key == K_PERIOD:
                        self.vehicleControl.gear = self.vehicleControl.gear + 1

                    elif event.key == K_l and pygame.key.get_mods() & KMOD_SHIFT:
                        current_lights ^= carla.VehicleLightState.HighBeam
                    #
                    elif event.key == K_l:
                        # Use 'L' key to switch between lights:
                        # closed -> position -> low beam -> fog
                        if not self._lights & carla.VehicleLightState.Position:
                            current_lights |= carla.VehicleLightState.Position
                        else:
                            current_lights |= carla.VehicleLightState.LowBeam
                        if self._lights & carla.VehicleLightState.LowBeam:
                            current_lights |= carla.VehicleLightState.Fog
                        if self._lights & carla.VehicleLightState.Fog:
                            current_lights ^= carla.VehicleLightState.Position
                            current_lights ^= carla.VehicleLightState.LowBeam
                            current_lights ^= carla.VehicleLightState.Fog
                    elif event.key == K_i:
                        current_lights ^= carla.VehicleLightState.Interior
                    elif event.key == K_z:
                        current_lights ^= carla.VehicleLightState.LeftBlinker
                    elif event.key == K_x:
                        current_lights ^= carla.VehicleLightState.RightBlinker

        self._parse_vehicle_keys(pygame.key.get_pressed(), clock.get_time())

        # Set automatic control-related vehicle lights
        if self.vehicleControl.brake:
            current_lights |= carla.VehicleLightState.Brake
        else:  # Remove the Brake flag
            current_lights &= ~carla.VehicleLightState.Brake
        if self.vehicleControl.reverse:
            current_lights |= carla.VehicleLightState.Reverse
        else:  # Remove the Reverse flag
            current_lights &= ~carla.VehicleLightState.Reverse

        if bool(status_speciallights):
            current_lights ^= carla.VehicleLightState.Special1
        else:
            if current_lights & carla.VehicleLightState.Special1 == carla.VehicleLightState(carla.VehicleLightState.Special1):
                current_lights ^= carla.VehicleLightState.Special1

        self._lights = current_lights

        if self.use_ackermann:
            self.vehicleControl = self.ego.get_control()
            return 0, current_lights, self._ackermann_control
        else:
            return 0, current_lights, self.vehicleControl
        #

    def _parse_vehicle_keys(self, keys, milliseconds):
        if keys[K_UP] or keys[K_w]:
            if not self.use_ackermann:
                self.vehicleControl.throttle = min(self.vehicleControl.throttle + 0.01, 1.00)
            else:
                self._ackermann_control.speed += round(milliseconds * 0.005, 2) * self._ackermann_reverse
        else:
            if not self.use_ackermann:
                self.vehicleControl.throttle = 0.0
            elif not (keys[K_DOWN] or keys[K_s]):
                self._ackermann_control.speed -= min(abs(self._ackermann_control.speed), round(milliseconds * 0.1, 2)) * self._ackermann_reverse
                self._ackermann_control.speed = max(0, abs(self._ackermann_control.speed)) * self._ackermann_reverse

        if keys[K_DOWN] or keys[K_s]:
            if not self.use_ackermann:
                self.vehicleControl.brake = min(self.vehicleControl.brake + 0.2, 1)
            else:
                self._ackermann_control.speed -= min(abs(self._ackermann_control.speed), round(milliseconds * 0.1, 2)) * self._ackermann_reverse
                self._ackermann_control.speed = max(0, abs(self._ackermann_control.speed)) * self._ackermann_reverse
        else:
            if not self.use_ackermann:
                self.vehicleControl.brake = 0

        steer_increment = 5e-4 * milliseconds
        if keys[K_LEFT] or keys[K_a]:
            if self._steer_cache > 0:
                self._steer_cache = 0
            else:
                self._steer_cache -= steer_increment
        elif keys[K_RIGHT] or keys[K_d]:
            if self._steer_cache < 0:
                self._steer_cache = 0
            else:
                self._steer_cache += steer_increment
        else:
            self._steer_cache = 0.0
        self._steer_cache = min(0.7, max(-0.7, self._steer_cache))
        if not self.use_ackermann:
            self.vehicleControl.steer = round(self._steer_cache, 1)
            self.vehicleControl.hand_brake = keys[K_SPACE]
        else:
            self._ackermann_control.steer = round(self._steer_cache, 1)
        #

    @staticmethod
    def _is_quit_shortcut(key):
        return (key == K_ESCAPE) or (key == K_q and pygame.key.get_mods() & KMOD_CTRL)
