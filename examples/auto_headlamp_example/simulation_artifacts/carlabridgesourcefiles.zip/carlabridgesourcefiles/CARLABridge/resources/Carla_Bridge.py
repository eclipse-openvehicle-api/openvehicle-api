
"""
***********************************************************************
* File Name   : carla_bridge.py
* Author      : Bharath Baskaran(Main Author)
* Modified    : Dheeraj Mandli (To fit VAPI examples)
* Created on  : 09-10-2025
* Description : Integration of CARLA simulator features for demonstrating VAPI features
* Version     : 1.0
* Last Update : 17-10-2025
*
* Based on    : CARLA Simulator (https://github.com/carla-simulator/carla)
* License     : Portions of this code are derived from CARLA, which is licensed under the MIT License.
*               See https://github.com/carla-simulator/carla/blob/master/LICENSE for details.
*
* Company     : ZF Friedrichshafen AG
*************************************************************************
"""

import carla
import random
import os
import sys
import time
import numpy
import threading
import configparser
import pygame
import pygame.gfxdraw
from pygame.locals import QUIT
import glob

import keyboard_control

import logging
from datetime import datetime

try:
    sys.path.append(glob.glob('../carla/dist/carla-*%d.%d-%s.egg' % (
        sys.version_info.major,
        sys.version_info.minor,
        'win-amd64' if os.name == 'nt' else 'linux-x86_64'))[0])
except IndexError:
    pass


# * accepting all logging levels *
logging.root.setLevel(level=logging.NOTSET)

# * creating logger*
logger = logging.getLogger('CARLABridge')
# * handler to write log file *
logFileHandler = logging.FileHandler(f'simulation_log_{datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}.log')
logFileFormatter = logging.Formatter(fmt='%(asctime)s %(name)s %(levelname)s Line %(lineno)d: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logFileHandler.setFormatter(logFileFormatter)
# * handler to output logs onto console *
logConsoleHandler = logging.StreamHandler()
logConsoleFormatter = logging.Formatter(fmt='%(message)s')
logConsoleHandler.setFormatter(logConsoleFormatter)
# * adding handlers to the logger *
logger.addHandler(logFileHandler)
logger.addHandler(logConsoleHandler)

# * global variables *
sim_stopped = False
fmu_rsrc_path = None
lid_out_str = ' '
pLidarPointCloud = None
nonego_vehicles = None
surfaces_to_blit = []
auto_pilot = 0
TSR_HMI = False

op_mode = 0   # * operation mode *

climates = {0: 'default', 1: 'ClearNoon', 2: 'CloudyNoon', 3: 'ClearSunset', 4: 'CloudySunset', 5: 'WetCloudyNoon',
            6: 'SoftRainNoon', 7: 'WetNoon', 8: 'MidRainyNoon', 9: 'HardRainNoon', 10: 'WetSunset', 11: 'WetCloudySunset',
            12: 'SoftRainSunset', 13: 'MidRainSunset', 14: 'HardRainSunset'}

current_weather = None

Door_FL = 0
Door_FR = 0
Door_RL = 0
Door_RR = 0
Headlight_Lowbeam = 0


class SpawnSensor:
    """
    CARLA Sensors use UE coordinate system ==>  (x-forward, y-right, z-up)
    """

    def __init__(self, sensor_type, publish=False):
        self.type = sensor_type
        self.publish_data = publish
        self.classify_sensor()

    def classify_sensor(self):
        if self.type == 'sensor.camera.rgb':
            self.width = None
            self.height = None
            self.fov = None
            self.gamma = None
            self.location = {'x': 0.0, 'y': 0.0, 'z': 0.0}
            self.rotation = {'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0}
            self.role_name = 'RGBCamera'

    def spawn_sensor(self, id):
        if self.type == 'sensor.camera.rgb':
            camera_actor = blueprint_lib.find(self.type)
            camera_actor.set_attribute('image_size_x', str(self.width))
            camera_actor.set_attribute('image_size_y', str(self.height))
            camera_actor.set_attribute('fov', str(self.fov))
            camera_actor.set_attribute('gamma', str(self.gamma))
            camera_actor.set_attribute('role_name', self.role_name)
            camera_transform = carla.Transform(carla.Location(x=self.location['x'], y=self.location['y'], z=self.location['z']),
                carla.Rotation(roll=self.rotation['roll'], pitch=self.rotation['pitch'], yaw=self.rotation['yaw']))

            camera = world.spawn_actor(camera_actor, camera_transform, attach_to=vehicle)

            camera_listenerFunc = 'listener__camera_'+str(id) if 'listener__camera_'+str(id) in globals().keys() else 'listener__camera_default'

            # * sensor listen function *
            camera.listen(lambda image: eval(camera_listenerFunc)(image) if self.publish_data else None) # bool(int(config['parameters']['publish_images'])) else None)

            return camera

def listener__camera_default(image):
    """
    Default listener functions for newly spawned RGB CAMERA sensor. This function will only be used if there is no
    separate listener function with format listener__camera_<id> is created.

    :return:
    """
    logger.info('HELLO FROM NEWLY SPAWNED CAMERA')

def spectate_vehicle(image):
    """
    Callback for the camera sensor that would be used as spectator. Based on the chosen display mode, the resolution
    of the image will be adjusted in the pygame display window.

    :param
        image: 32-bit BGRA array of image captured by camera sensor

    :return:

    """

    image.convert(carla.ColorConverter.Raw)

    bgra_array = numpy.frombuffer(image.raw_data, dtype=numpy.dtype("uint8"))
    data = numpy.reshape(bgra_array, (image.height, image.width, 4))
    data = data[:, :, :3]
    data = data[:, :, ::-1]

    surf = pygame.surfarray.make_surface(data.swapaxes(0, 1))

    surf_scaled = pygame.transform.scale(surf, (704, 720))

    # * using insert instead of append so the upcoming surfaces will be blitted on top of this main spectator image *
    surfaces_to_blit.insert(0, (surf_scaled, (320, 0)))

    del bgra_array, data


def paint_vehicle_trajectory():
    """
    Function to visualize the trajectory of the vehicle on the server side of CARLA by drawing a colored dot on the
    coordinates, which correspond to the position of the vehicle at that instant of time.

    :return:

    """
    while not sim_stopped:
        world.debug.draw_point(location=vehicle.get_transform().location, size=0.035,
                               color=carla.Color(r=255, g=255, b=0, a=128), life_time=2)

        time.sleep(0.01)  # ToDo: Check if method to wait for world.tick() is available and could be used


def paint_lanes():
    """
    Function to highlight the lane in which the vehicle is driving on the server side of CARLA by drawing a colored dot
    on the waypoint coordinate at the lane borders; measured from a waypoint generated based on the position of the
    vehicle at that instant of time.

    :return:

    """

    while not sim_stopped:
        currentWayPoint = world.get_map().get_waypoint(location=vehicle.get_location(), lane_type=carla.LaneType.Driving,
                                                       project_to_road=True)

        for i in numpy.arange(start=0,stop=5,step=0.5):
            guidanceWayPoint = currentWayPoint.next(i+3)[0]

            laneLeftBoder = guidanceWayPoint.transform.transform(carla.Location(x=0, y=guidanceWayPoint.lane_width/2 * -1, z=0))
            laneRightBoder = guidanceWayPoint.transform.transform(carla.Location(x=0, y=guidanceWayPoint.lane_width/2, z=0))

            world.debug.draw_point(location=carla.Location(laneLeftBoder), size=0.07, color=carla.Color(r=0, b=0, g=255, a=0),
                                   life_time=1)
            world.debug.draw_point(location=carla.Location(laneRightBoder), size=0.07, color=carla.Color(r=0, b=0, g=255, a=0),
                                   life_time=1)

        time.sleep(0.01)  # ToDo: Check if method to wait for world.tick() is available and could be used


def draw_trajectory():
    """
    Function to instantiate and start a thread, with the function 'paint_vehicle_trajectory' as target, based on the
    input from config file (*ini).

    :return:

    """
    if bool(int(config['parameters']['paint_vehicle_traj'])):
        threading.Thread(target=paint_vehicle_trajectory,args=()).start()

    if bool(int(config['parameters']['highlight_lanes'])):
        threading.Thread(target=paint_lanes,args=()).start()

    return


def change_view(mode):
    """
    Function to change the spectator view during runtime.

    :param
        mode: string containing the name of view to set
    :return:

    """
    global current_view, vehicle

    logger.info(f'changing view to {mode}')

    if mode == 'follow-vehicle':
        spectator_transform = carla.Transform(carla.Location(x=-6.5, y=0.0, z=3.0), carla.Rotation(roll=0.0, yaw=0.0, pitch=0.0))
        current_view = 'follow-vehicle'
    elif mode == 'birdeye':
        spectator_transform = carla.Transform(carla.Location(z=20), carla.Rotation(pitch=-90))
        current_view = 'birdeye'
    elif mode == 'custom':
        location = [float(coordinate) for coordinate in config['parameters']['spectator_location'].split(',')]
        orientation = [float(angle) for angle in config['parameters']['spectator_orientation'].split(',')]
        spectator_transform = carla.Transform(carla.Location(x=location[0], y=location[1], z=location[2]),
                                              carla.Rotation(roll=orientation[0], pitch=orientation[1], yaw=orientation[2]))
        current_view = 'custom'
    elif mode == 'topview':
        spectator_transform = carla.Transform(carla.Location(x=-7, y=0, z=45), carla.Rotation(pitch=-80))
        current_view = 'topview'
    elif mode == '' or mode is None or mode == 'default' or 'spectator_mode' not in config['parameters']:
        spectator_transform = world.get_spectator().get_transform()
        current_view = 'default'

    return spectator_transform


def change_weather(weatherId):
    """
    Function to change the weather of CARLA world
    :param
        weatherId: key value that will be used to get the corresponding weather from climate dictionary

    :return:
    """
    global current_weather

    if weatherId != current_weather:
        if weatherId > 0:
            logger.info(f'Setting weather to {climates[weatherId]}')
            world.set_weather(eval('carla.WeatherParameters.' + climates[weatherId]))
        current_weather = weatherId


def initialize_carla():
    """
    Function to establish connection with an active CARLA Server and configure the CARLA world based on the inputs
    provided in the *.ini file

    :return:

    """

    global sim_stopped, actor_list, world, config, screen, vehicle_control, clock, vehicle_lights, carla_client, auto_pilot, current_weather

    pygame.init()
    screen_width = 1024
    screen_height = 720
    screen = pygame.display.set_mode((screen_width, screen_height), flags=pygame.DOUBLEBUF | pygame.HWSURFACE)
    icon = pygame.image.load(os.path.join(fmu_rsrc_path,'ZF_logo.png')).convert_alpha()
    pygame.display.set_icon(icon)
    pygame.display.set_caption('SofDCar')

    # * initially fill with color: gray *
    screen.fill((128, 128, 128))

    # * updating the display *
    pygame.display.flip()

    # * parsing *.ini file *
    config = configparser.ConfigParser()
    config.read(os.path.join(fmu_rsrc_path,'SimulationConfig.ini'))

    # * connecting to CARLA server *
    carla_client = carla.Client(config['parameters']['server_ip'], int(config['parameters']['server_port']))
    carla_client.set_timeout(60)

    # * list to collect all spawned actors *
    actor_list = []

    # * Loading map to CARLA world *
    if config['parameters']['map'].endswith('.umap') or config['parameters']['map'] != "" and \
            config['parameters']['map'] != 'default' and not config['parameters']['map'].endswith('.xodr'):
        logger.info(f'LOADING MAP:  {config["parameters"]["map"]}')
        world = carla_client.load_world(config['parameters']['map'])
    #
    elif config['parameters']['map'].endswith('.xodr'):
        # * loading map from xodr file *
        logger.info('Loading OpenDrive map %r.' % os.path.basename(config['parameters']['map']))
        xodr_path = config['parameters']['map']
        if os.path.exists(xodr_path):
            with open(xodr_path, encoding='utf-8') as od_file:
                try:
                    data = od_file.read()
                except OSError:
                    raise FileExistsError('File does not exist.')
                    sys.exit()
        vertex_distance = 2.0  # in meters
        max_road_length = 500.0  # in meters
        wall_height = 0.0  # in meters
        extra_width = 0.6  # in meters
        world = carla_client.generate_opendrive_world(
            data, carla.OpendriveGenerationParameters(
                vertex_distance=vertex_distance,
                max_road_length=max_road_length,
                wall_height=wall_height,
                additional_width=extra_width,
                smooth_junctions=True,
                enable_mesh_visibility=True))
    #
    elif config['parameters']['map'] == 'default' or config['parameters']['map'] in ['', None, ' '] \
            or 'map' not in config['parameters'].keys():
        logger.info('Connecting to the preloaded world in server')
        world = carla_client.get_world()

    if 'weather' in config['parameters'].keys() and config['parameters']['weather'] != 'default':
        world.set_weather(eval('carla.WeatherParameters.' + config['parameters']['weather']))
        current_weather = [items[0] for items in climates.items() if items[1] == config['parameters']['weather']][0]
        logger.info(f'Setting weather to {config["parameters"]["weather"]}')

    # * light states *
    vehicle_lights = carla.VehicleLightState.NONE

    # * Pygame display mode *
    globals()['disp_mode'] = int(config['parameters']['display_mode'])

    # * deploying scenario*
    vehicle, blueprint_lib, vehicle_control, clock = configureScenario(0)

    # * configuring auto_pilot mode *
    if bool(int(config['parameters']['auto_pilot'])) and config['initialization']['vehicle_control'] == 'autonomous':
        try:
            vehicle.set_autopilot(True)
            auto_pilot = 1
            world.tick()
        except:
            pass


def configureScenario(scenario):
    """
    Deploying selected scenario on the CARLA world.

    :param
        scenario:
    :return:
        vehicle - Reference to the Carla Vehicle (Actor)
    """
    global actor_list, select_view, current_view, blueprint_lib, vehicle

    # * configuring simulation world settings *
    if bool(int(config['parameters']['carla_sync_mode'])):
        settings = world.get_settings()
        settings.fixed_delta_seconds = float(config['parameters']['fixed_delta_sec'])
        settings.synchronous_mode = bool(int(config['parameters']['carla_sync_mode']))
        settings.no_rendering_mode = bool(int(config['initialization']['disable_server_rendering']))
        world.apply_settings(settings)

    # * orienting spectator *
    location = [float(coordinate) for coordinate in config['parameters']['spectator_location'].split(',')]
    orientation = [float(angle) for angle in config['parameters']['spectator_orientation'].split(',')]
    world.get_spectator().set_transform(carla.Transform(carla.Location(x=location[0], y=location[1], z=location[2]),
                                                        carla.Rotation(roll=orientation[0], pitch=orientation[1],
                                                                       yaw=orientation[2])))

    # * handle to carla blueprint library *
    blueprint_lib = world.get_blueprint_library()

    # * fetching desired vehicle blueprint to spawn*
    vehicle_bp = blueprint_lib.find(config['parameters']['vehicle'])
    vehicle_bp.set_attribute('role_name', 'ego_vehicle')


    logger.info(f'Spawning vehicle')

    if scenario is None :  # scenario not in list(scenes.values()):
        scenario = 0

    logger.info(f'Configuring world for scenario: Free-drive')

    if scenario in [0, 1, 2, 3, 4]:
        if config['parameters']['vehicle_start_position'] == 'random' or config['parameters']['vehicle_start_orientation'] == 'random':
            randompoint = random.choice(world.get_map().get_spawn_points())
            # logger.info(f"random Spawn Point : Location({randompoint.location.x:.2f}, {randompoint.location.y:.2f}, {randompoint.location.z:.2f}), Rotation(yaw={randompoint.rotation.yaw:.2f})")
            spawn_points = world.get_map().get_spawn_points()
            vehicle = world.spawn_actor(vehicle_bp,randompoint)

        else:
            vehicle_spawn_pos = config['parameters']['vehicle_start_position'].split(',')
            vehicle_spawn_orient = config['parameters']['vehicle_start_orientation'].split(',')
            vehicle = world.spawn_actor(vehicle_bp, carla.Transform(carla.Location(x=float(vehicle_spawn_pos[0]), y=float(vehicle_spawn_pos[1]), z=float(vehicle_spawn_pos[2])),
                                                                    carla.Rotation(roll=float(vehicle_spawn_orient[0]), pitch=float(vehicle_spawn_orient[1]), yaw=float(vehicle_spawn_orient[2]))))

    else:
        raise Exception('\nNo appropriate Scenario found')
        sys.exit()

    # * Configuring manual control mode *
    vehicle_control = keyboard_control.ManualControl(vehicle, bool(int(config['parameters']['ackermann_control'])),
                                                     reset_or_quit, vehicle_lights)
    clock = pygame.time.Clock()

    actor_list.append(vehicle)

    # * Configuring vehicle sensors *
    if int(config['initialization']['count_rgb_camera_sensor']) > 0:
        for i in range(int(config['initialization']['count_rgb_camera_sensor'])):
            camera = SpawnSensor('sensor.camera.rgb', publish=bool(int(config[f'camera_{i}']['publish_data'])))
            camera.width = int(config[f'camera_{i}']['width'])
            camera.height = int(config[f'camera_{i}']['height'])
            camera.fov = float(config[f'camera_{i}']['fov'])
            camera.gamma = float(config[f'camera_{i}']['gamma'])

            camera.location['x'] = float(config[f'camera_{i}']['location'].split(',')[0])
            camera.location['y'] = float(config[f'camera_{i}']['location'].split(',')[1])
            camera.location['z'] = float(config[f'camera_{i}']['location'].split(',')[2])

            camera.rotation['roll'] = float(config[f'camera_{i}']['rotation'].split(',')[0])
            camera.rotation['pitch'] = float(config[f'camera_{i}']['rotation'].split(',')[1])
            camera.rotation['yaw'] = float(config[f'camera_{i}']['rotation'].split(',')[2])
            camera.role_name = config[f'camera_{i}']['name']

            actor_ref = camera.spawn_sensor(id=i)

            actor_list.insert(0, actor_ref)

    # * spawning RGB camera to act as spectator *
    spectator_camera = blueprint_lib.find('sensor.camera.rgb')
    spectator_camera.set_attribute('image_size_x', '1024')
    spectator_camera.set_attribute('image_size_y', '720')
    spectator_camera.set_attribute('fov', '90')
    spectator_camera.set_attribute('gamma', '2.2')
    spectator_camera.set_attribute('role_name', 'spectator_camera')

    spectator_modes = {0: 'default', 1: 'follow-vehicle', 2: 'birdeye', 3: 'topview', 4: 'custom'}

    # * default view *
    select_view = [item[0] for item in spectator_modes.items() if item[1] == config['parameters']['spectator_mode']][0]

    # * spawning spectator camera *
    spectator_camera_actor = world.spawn_actor(spectator_camera, change_view(config['parameters']['spectator_mode']),
                                               attach_to=vehicle)

    current_view = config['parameters']['spectator_mode']

    spectator_camera_actor.listen(lambda image: [spectator_camera_actor.set_transform(change_view(spectator_modes[select_view])) if select_view in range(0, 5) and current_view != spectator_modes[select_view] else None, spectate_vehicle(image) if bool(int(config['parameters']['spectate_vehicle'])) else None])

    actor_list.insert(0, spectator_camera_actor)

    # * advancing a step to apply settings *
    if bool(int(config['parameters']['carla_sync_mode'])):
        world.tick()

    return vehicle, blueprint_lib, vehicle_control, clock


def stop_simulation():
    """
    Function to end all spawned threads, destroy all actors, terminate visualization and stop simulation

    :return:

    """
    global sim_stopped
    logger.info('Stopping Simulation')

    sim_stopped = True
    settings = world.get_settings()
    settings.synchronous_mode = False
    settings.fixed_delta_seconds = 0.0
    world.apply_settings(settings)

    time.sleep(1)

    logger.info('Destroying all Actors')
    for each_actor in actor_list:
        each_actor.destroy()

    time.sleep(1)

    logger.info('Exiting pygame')
    # pygame.mixer.music.unload()
    pygame.quit()

    time.sleep(1)


def apply_vehicle_control(u_throttle, u_steer, u_brake, status_speciallights, status_buzzer):
    """
    Function to apply control values on the spawned vehicle during manual/autonomous driving mode (auto_pilot = False)

    Also, the simulation world is updated/advanced with the applied control values to next step.

    :param u_throttle: throttle/speed to be applied on the vehicle (float)
    :param u_steer: steering angle to be applied on the vehicle (float)
    :param u_brake: brake to be applied on the vehicle (float)
    :param status_speciallights: toggle special lights (e.g. siren) ON / OFF
    :param status_buzzer: toggle buzzer sound (e.g. siren beep) ON / OFF

    :return:
        sim_status - status of simulation. 0 -> continue simulation, 1 -> stop simulation and exit

    """
    global vehicle_lights, Door_FL, Door_FR, Door_RL, Door_RR , Headlight_Lowbeam

    sim_status = 0

    if Door_FL: 
        vehicle.open_door(carla.VehicleDoor.FL)
    else:
        vehicle.close_door(carla.VehicleDoor.FL)

    if Door_FR: 
        vehicle.open_door(carla.VehicleDoor.FR)
    else:
        vehicle.close_door(carla.VehicleDoor.FR)

    if Door_RL: 
        vehicle.open_door(carla.VehicleDoor.RL)
    else:
        vehicle.close_door(carla.VehicleDoor.RL)
    
    if Door_RR: 
        vehicle.open_door(carla.VehicleDoor.RR)
    else:
        vehicle.close_door(carla.VehicleDoor.RR)
    
    if Headlight_Lowbeam:
        vehicle_light_state = carla.VehicleLightState(carla.VehicleLightState.LowBeam | carla.VehicleLightState.HighBeam)
        vehicle.set_light_state(vehicle_light_state)
    else:
        vehicle.set_light_state(carla.VehicleLightState.NONE)

    # *  *    manual and autonomous driving mode   *  *
    def manual_driving(run_status, light_status, control_mode):
        clock.tick_busy_loop(60)
        run_status, light_status, tgt_veh_control = vehicle_control.parse_events(clock, status_speciallights)

        # if bool(int(config['parameters']['ackermann_control'])):
        #     vehicle.apply_ackermann_control(carla.VehicleAckermannControl(speed=tgt_veh_control.speed if (tgt_veh_control.speed >= 1.2 or tgt_veh_control.speed <= -1.2) else 0, steer=tgt_veh_control.steer, steer_speed=2.0))

        # else:
        vehicle.apply_control(tgt_veh_control)

        return run_status, light_status
    #

    def autonomous_driving(run_status, light_status, control_mode):
        if not bool(int(config['parameters']['auto_pilot'])) and auto_pilot == 0:
            # * controlling vehicle with feedback *
            if control_mode in [0, 1]:
                vehicle.apply_control(carla.VehicleControl(throttle=u_throttle, brake=u_brake, steer=u_steer))

            else:
                """
                control_modes:
                    -> 2 :: {Lat: SW   Long: Driver}
                    -> 3 :: {Lat: Driver   Long: Sw}
                """

                clock.tick_busy_loop(60)
                run_status, light_status, tgt_veh_control = vehicle_control.parse_events(clock, status_speciallights)

                if control_mode == 2:
                    vehicle.apply_control(carla.VehicleControl(throttle=tgt_veh_control.throttle, brake=tgt_veh_control.brake, steer=u_steer, reverse=tgt_veh_control.reverse))

                if control_mode == 3:
                    vehicle.apply_control(carla.VehicleControl(throttle=u_throttle, brake=u_brake, steer=tgt_veh_control.steer))


        # * Enabling/Disabling autopilot *
        try:
            vehicle.set_autopilot(bool(int(auto_pilot)))
        except:
            pass

        # * check for special light activation *
        if bool(status_speciallights):
            light_status |= carla.VehicleLightState.Special1
        else:
            light_status &= ~carla.VehicleLightState.Special1

        for event in pygame.event.get():
            if event.type == QUIT:
                return reset_or_quit(), light_status

        return run_status, light_status

    # *  SW Modes   *
    if op_mode in [1, 2, 3]:
        sim_status, vehicle_lights = autonomous_driving(sim_status, vehicle_lights, op_mode)

    elif op_mode == 4:
        sim_status, vehicle_lights = manual_driving(sim_status, vehicle_lights, op_mode)

    elif op_mode not in range(1,5):
        if config['initialization']['vehicle_control'] == 'manual':
            sim_status, vehicle_lights = manual_driving(sim_status, vehicle_lights, 0)
        #
        elif config['initialization']['vehicle_control'] == 'autonomous':
            sim_status, vehicle_lights = autonomous_driving(sim_status, vehicle_lights, 0)

    if sim_status == 1:
        return sim_status

    # * updating light states *
    # vehicle.set_light_state(carla.VehicleLightState(vehicle_lights))

    if bool(int(config['parameters']['carla_sync_mode'])):
        world.tick()

    # * creating/updating sensor display surface *
    if globals()['disp_mode'] != 1:
        # * surface for CAMERA sensor display *
        sensorSurface = pygame.image.load(os.path.join(fmu_rsrc_path, 'noPreview.png')).convert_alpha()
        sensorSurface_Scaled = pygame.transform.scale(sensorSurface, (320, 180))
        surfaces_to_blit.append((sensorSurface_Scaled, (0, 180)))

    # * updating HMI surface *
    setupHMI()

    # * update visualization *
    screen.blits(surfaces_to_blit, False)
    pygame.display.flip()

    surfaces_to_blit.clear()

    return sim_status


def listener__camera_0(image):
    """
    Function to extract the image data captured by the camera sensor and apply necessary conversions to transmit it
     in the desired format.

    At the end of conversion, the event  'complete_step' is set to True, thereby acknowledging to update
    visualization.

    :param
        image: image data (carl.Image) captured by the sensor

    :return:

    """

    # # global rgb_array

    image.convert(carla.ColorConverter.Raw)

    bgra_array = numpy.frombuffer(image.raw_data, dtype=numpy.dtype("uint8"))
    data = numpy.reshape(bgra_array, (image.height, image.width, 4))
    data = data[:, :, :3]

    data = data[:, :, ::-1]

    if globals()['disp_mode'] == 1:
        surf = pygame.surfarray.make_surface(data.swapaxes(0, 1))
        surf_f = pygame.transform.scale(surf, (320, 180))
        surfaces_to_blit.append((surf_f, (0, 180)))

    del bgra_array, data


def configure():
    """
    Function to parse the signal mapping *.csv file and create a dictionary of mappings.

    :return:

    """
    global fmu_get_mapping

    fmu_get_mapping = {'UC': [0,0], 'ARC': [0,0], 'CS': [0,0]}

    # * parsing signal mapping csv file *
    file = open(os.path.join(fmu_rsrc_path,config['arguments']['mapping_file']), mode='r+')
    content = file.readlines()

    for eachline in content:
        row_entry = eachline.split(';')
        if row_entry[0] != 'messageid' and row_entry[6] == 'OUT':
            fmu_get_mapping[row_entry[1]] = [row_entry[3], row_entry[4]] if row_entry[1] not in fmu_get_mapping.keys() else logger.warning(f'Duplicate entry for {row_entry[1]} not allowed')

    return


def compute_value(signal):
    """
    Function to compute values for signals for which no direct access variable's area available.

    :return:
        computed signal value
    """

    if signal == 'Door_FL':
        return Door_FL
    if signal == 'Door_FR':
        return Door_FR
    if signal == 'Door_RL':
        return Door_RL
    if signal == 'Door_RR':
        return Door_RR
    
    if signal == 'Headlight_Lowbeam':
        return Headlight_Lowbeam
    
def get_values(signal):
    """
    Function to be called by the calculate_values() method of fmi to update the fmu outport variables with the
    appropriate CARLA quantity.

    :param
        signal: signal name 'key' that will be passed to mapping dictionary (fmu_get_mapping)

    :return:

    """
    
    return eval(fmu_get_mapping[signal][0])*eval(fmu_get_mapping[signal][1])

def reset_or_quit():
    """
    Function to create a pop-up on closing of pygame window with the options to either reset or quit
    simulation.

    :return:
    """

    dialog_width = 320
    dialog_height = 180

    button_width = 120
    button_height = 50

    popup_window = pygame.surface.Surface((dialog_width, dialog_height))
    popup_window.fill((255, 255, 255))

    screen_width = pygame.display.get_surface().get_size()[0]
    screen_height = pygame.display.get_surface().get_size()[1]

    title_bar = pygame.surface.Surface((dialog_width, 25))
    title_bar.fill((128, 128, 128))

    reset_button_surface = pygame.surface.Surface((button_width, button_height))
    reset_button = pygame.Rect(screen_width/2 - popup_window.get_size()[0]/2 + 20, screen_height/2 - button_height / 2, button_width, button_height)

    quit_button_surface = pygame.surface.Surface((button_width, button_height))
    quit_button = pygame.Rect(screen_width/2 - popup_window.get_size()[0]/2 + 180, screen_height/2 - button_height/2, button_width, button_height)

    terminate_icon_surf = pygame.surface.Surface((25, 25))
    terminate_icon_surf.fill((0, 0, 255))

    terminate_icon_rect = pygame.Rect(screen_width/2 + popup_window.get_size()[0]/2 - terminate_icon_surf.get_size()[0], screen_height/2 - popup_window.get_size()[1]/2, 25, 25)

    __font = pygame.font.SysFont(name='Calibri', size=24, bold=True, italic=False)

    reset_font = __font.render('Reset', True, (255,255,255))

    quit_font = __font.render('Quit', True, (255, 255, 255))

    terminate_icon_font = __font.render('X', True, (255, 255, 255))

    color_code = {'hover': (255, 255, 0), 'normal': (0, 0, 255), 'pressed': (0, 255, 0), 'Terminate': (255, 0, 0)}

    while True:
        mouse_ptr_location = pygame.mouse.get_pos()
        reset_button_surface.fill(color_code['normal'])
        quit_button_surface.fill(color_code['normal'])
        terminate_icon_surf.fill(color_code['normal'])

        # * checking if mouse pointer on button and if click is performed *
        if terminate_icon_rect.collidepoint(mouse_ptr_location):
            terminate_icon_surf.fill(color_code['Terminate'])
            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                terminate_icon_surf.fill(color_code['pressed'])
                return 0

        if reset_button.collidepoint(mouse_ptr_location):
            reset_button_surface.fill(color_code['hover'])
            # * checking if mouse click action was performed when
            # pointer is over the button *
            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                reset_button_surface.fill(color_code['pressed'])
                stop_simulation()

                logger.info('Reinitializing simulation world')
                initialize_carla()
                return 0

        if quit_button.collidepoint(mouse_ptr_location):
            quit_button_surface.fill(color_code['hover'])
            # * checking if mouse click action was performed when
            # pointer is over the button *
            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                quit_button_surface.fill(color_code['pressed'])
                stop_simulation()
                return 1

        # * blitting buttons to window *
        reset_button_surface.blit(reset_font, (reset_button.width / 2 - reset_font.get_rect().width / 2,
                                               reset_button.height / 2 - reset_font.get_rect().height / 2))
        quit_button_surface.blit(quit_font, (quit_button.width/2 - quit_font.get_rect().width/2,
                                            quit_button.height/2 - quit_font.get_rect().height/2))

        terminate_icon_surf.blit(terminate_icon_font, (terminate_icon_surf.get_rect().width/2 - terminate_icon_font.get_rect().width/2,
                                                       terminate_icon_surf.get_rect().height/2 - terminate_icon_font.get_rect().height/2))

        title_bar.blit(terminate_icon_surf, (title_bar.get_rect().width - terminate_icon_surf.get_rect().width,0))

        popup_window.blit(title_bar, (0,0))
        popup_window.blit(reset_button_surface, (20, popup_window.get_size()[1] / 2 - reset_button_surface.get_size()[1] / 2))
        popup_window.blit(quit_button_surface, (180, popup_window.get_size()[1] / 2 - quit_button_surface.get_size()[1] / 2))

        screen.blit(popup_window, (screen_width / 2 - popup_window.get_size()[0] / 2, screen_height / 2 - popup_window.get_size()[1] / 2))

        # * updating pygame display *
        pygame.event.get()
        pygame.display.flip()


def reset_scenario(scenario_id):
    """
    Function to reset scenario. When called, all the actors present in the world will be destroyed.

    And then the new scenario will be deployed.

    :return:
    """
    global vehicle, blueprint_lib, vehicle_control, clock, current_view, actor_list, world

    logger.info(f'Received new scenario value {scenario_id}')

    # if scenario_id not in scenes.values():
    #     logger.warning('No scenario configured for this Id. Please choose a valid scenario Id.', end='\n', flush=True)
    #     return

    logger.info(f'Resetting CARLA World ..')
    # * Deactivating synchronous mode before reset  *
    if bool(int(config['parameters']['carla_sync_mode'])):
        settings = world.get_settings()
        settings.fixed_delta_seconds = float(config['parameters']['fixed_delta_sec'])
        settings.synchronous_mode = False
        settings.no_rendering_mode = bool(int(config['initialization']['disable_server_rendering']))
        world.apply_settings(settings)

        # * creating traffic manager instance *
        traffic_manager = carla_client.get_trafficmanager()
        traffic_manager.set_synchronous_mode(False)

    logger.info('Destroying all Actors')
    for eachActor in actor_list:
        eachActor.destroy()

    # * setting current view to '' ; so that at the next tick the position spectator camera will be transformed
    #   using the lately spawned vehicle as reference *
    current_view = ''

    # * clearing all surfaces from list *
    surfaces_to_blit.clear()

    # * resetting actors list *
    actor_list.clear()

    vehicle, blueprint_lib, vehicle_control, clock = configureScenario(0)


def displayMessage(text, R_value, G_value, B_value):
    """
    Function to display the text from Truck-SW containing the status info.
    A maximum of 16 characters could be displayed.

    :param text: the message to be displayed
    :param R_value: R-Value of the RGB color code for background
    :param G_value: G-Value of the RGB color code for background
    :param B_value: B-Value of the RGB color code for background

    :return: -
    """
    frameSurface = pygame.image.load(os.path.join(fmu_rsrc_path, 'lcd_frame.jpg')).convert_alpha()
    frameSurface_scaled = pygame.transform.scale(frameSurface, (320, 180))

    surf = pygame.surface.Surface((302, 162))   # (320, 180))
    surf.fill((R_value, G_value, B_value))

    __font = pygame.font.SysFont(name='Arial', size=24, bold=True, italic=False)

    fontColor = (128, 0, 0) if ((R_value == 255) and (G_value == 255) and (B_value == 255)) else (255, 255, 255)

    for i in range(len(text.split('\n')[0])):
        # * Max limit 16 Chars *
        if i >= 16:
            break

        # * creating surface for each character *
        charSurface = pygame.surface.Surface((37.75, 81))
        charSurface.set_colorkey((0, 0, 0))
        try:
            charFont = __font.render(text.split('\n')[0][i], True, fontColor)
        except:
            charFont = __font.render(" ", True, (255, 255, 255))
        charSurface.blit(charFont, (charSurface.get_rect().width / 2 - charFont.get_size()[0] / 2,
                                    charSurface.get_rect().height / 2 - charFont.get_size()[1] / 2))
        # * Displaying as two row text *
        if i < 8:
            surf.blit(charSurface, (i*37.75, 0))
        else:
            surf.blit(charSurface, ((i-8) * 37.75, 81))

    frameSurface_scaled.blit(surf, (10.5, 10.5))
    surfaces_to_blit.append((frameSurface_scaled, (0, 0)))


def setupHMI():
    """
    Function to deploy & update the HMI surface on pygame screen

    :return:
    """

    # global auto_pilot, TSR_HMI
    baseSurface = pygame.image.load(os.path.join(fmu_rsrc_path, 'HMI', 'HMIScreen.jpg')).convert_alpha()
    HMIsurface = pygame.transform.scale(baseSurface, (320, 360))

    # * blitting to main screen *
    surfaces_to_blit.append((HMIsurface, (0, 360)))
