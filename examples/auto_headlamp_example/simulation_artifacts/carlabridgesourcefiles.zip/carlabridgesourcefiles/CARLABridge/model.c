
/***********************************************************************
 * File Name   : model.c
 * Modified    : Bharath Baskaran , Dheeraj Mandli.
 * Created on  : 09-10-2025
 * Description : Integration of CARLA simulator features for demonstrating VAPI features
 * Version     : 1.0
 * Last Update : 09-10-2025
 *
 * Based on    : 
 * License     : 
 *
 * Company     : ZF Friedrichshafen AG
 ***********************************************************************/


#include <float.h>
#include <math.h>
#include "config.h"
#include "model.h"
#include <python.h>
#include <windows.h>

#ifdef pipeForLidarPC
#define BUFSIZE 1210
#define pipename "\\\\.\\pipe\\PrimaryLidar"
HANDLE pipe;
#endif

#ifdef pipeForCamera
#define BUFSIZE_FRONTCAMERA 57600
#define pipename_FRONTCAMERA "\\\\.\\pipe\\MBCoupeFrontCamera"
HANDLE pipe_FrontCamera;
#endif

static int resetScenario = 0;

PyObject* mod_handle;

void setStartValues(ModelInstance *comp) {

    char res_path[FILENAME_MAX];
    strncpy(res_path, comp->resourceLocation+8, strlen(comp->resourceLocation));

    Py_Initialize();

    /*   acquiring GIL lock to avoid segmentation faults   */
    PyGILState_STATE gstate = PyGILState_Ensure();

    // Add virtual environment packages to sys path.
	const char *old_path = Py_EncodeLocale(Py_GetPath(), NULL);
	const char *venv_path = getenv("PYVENVLIB");
	size_t totalLen = strlen(venv_path) + strlen(old_path) + 2; // + 1 for null terminator and + 1 for separator ":" or ";" (Linux or Windows)
	char *concatenated = (char *)malloc(totalLen);

	strcpy(concatenated, venv_path);
	#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
		strcat(concatenated, ";");
	#else
		strcat(concatenated, ":");
	#endif
	strcat(concatenated, old_path);

	wchar_t* decoded_path = Py_DecodeLocale(concatenated, NULL);
    PySys_SetPath(decoded_path);
    
    PyRun_SimpleString("print('Initializing CARLA World ...')");
    

    /*  Importing py file as module and generating handles to functions in it*/
    PyObject *sys_path, * additional_path;

    sys_path = PySys_GetObject("path");

    additional_path = PyUnicode_FromString(res_path);

    PyList_Append(sys_path,additional_path);
    PySys_SetObject("path", sys_path);
    

    PyObject* mod_name = PyUnicode_FromString("Carla_Bridge");
    mod_handle = PyImport_Import(mod_name);

    
    if (mod_handle == NULL) {
		PyErr_Print();
	}

    /*  sending resource location to Py-variable  */
    PyObject* rsrc_path = Py_BuildValue("(s)", res_path);
    PyObject_SetAttrString(mod_handle,"fmu_rsrc_path",PyTuple_GetItem(rsrc_path, 0));
    Py_DecRef(rsrc_path);


    /*  Initializing & Instantiating CARLA world  */
    PyObject* hndl_initializeCarla = PyObject_GetAttrString(mod_handle, "initialize_carla");

    if (hndl_initializeCarla && PyCallable_Check(hndl_initializeCarla))
    {
        PyObject_CallObject(hndl_initializeCarla,NULL);
    }
    else
    {
        printf("\n Python Function initialize_carla is either not callable or the function handle could not be created \n");
    }
    

    /*  drawing trajectory  */
    PyObject* hndl_drawVehTrajectory = PyObject_GetAttrString(mod_handle, "draw_trajectory");
    PyObject_CallObject(hndl_drawVehTrajectory, NULL);
   

    /* configuring py-simulation variables */
    PyObject* hndl_configSignalMapping = PyObject_GetAttrString(mod_handle,"configure");
    PyObject_CallObject(hndl_configSignalMapping,NULL);

    Py_DECREF(hndl_initializeCarla);
    Py_DECREF(hndl_drawVehTrajectory);
    Py_DECREF(hndl_configSignalMapping);

    PyGILState_Release(gstate);

    #ifdef pipeForLidarPC
    /* creating pipe (method for IPC ) to exchange LIDAR data */
    // For Primary LIDAR
    pipe = CreateNamedPipe(pipename, PIPE_ACCESS_INBOUND | PIPE_ACCESS_OUTBOUND , PIPE_NOWAIT, PIPE_UNLIMITED_INSTANCES, BUFSIZE*sizeof(double), BUFSIZE*sizeof(double), 120 * 1000, NULL);

    if (pipe == INVALID_HANDLE_VALUE)
    {
        printf("Error: %ld", GetLastError());
    }
    #endif

    /* creating pipe (method for IPC ) to exchange CAMERA data */
    #ifdef pipeForCamera
    pipe_FrontCamera = CreateNamedPipe(pipename_FRONTCAMERA, PIPE_ACCESS_INBOUND | PIPE_ACCESS_OUTBOUND , PIPE_NOWAIT, 1, BUFSIZE_FRONTCAMERA*sizeof(int), BUFSIZE_FRONTCAMERA*sizeof(int), 120 * 1000, NULL);

    if (pipe_FrontCamera == INVALID_HANDLE_VALUE)
    {
        printf("Error: %ld", GetLastError());
    }
    #endif

    comp->nextEventTime        = 0;
    comp->nextEventTimeDefined = true;

}


Status calculateValues(ModelInstance *comp) {
    UNUSED(comp);

    /* Calculating the outport values at end of each step */

    PyGILState_STATE gstate = PyGILState_Ensure();

    PyObject* hndl_getSignalValues = PyObject_GetAttrString(mod_handle, "get_values");

    M(CARLAout__act_speed) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_speed")));
    M(CARLAout__act_steering) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_steering")));
    M(CARLAout__act_pos_x) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_pos_x")));
    M(CARLAout__act_pos_y) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_pos_y")));
    M(CARLAout__act_yaw_angle) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_yaw_angle")));
    M(CARLAout__act_lat_acceleration) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_lat_acceleration")));
    M(CARLAout__current_speed_limit) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "current_speed_limit")));
    
    // strcpy(M(CARLAout__park_coordinates), PyUnicode_AsUTF8(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "park_coordinates"))));
    
    /* fetching LIDAR point cloud data  */
    // strcpy(M(CARLAout__lidar_points_primary), PyUnicode_AsUTF8(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "lidar_points_primary"))));
    //
    // strcpy(M(CARLAout__lidar_pc_front_secondary), PyUnicode_AsUTF8(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "lidar_pc_secondary"))));

    M(CARLAout__act_pos_z) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_pos_z")));
    M(CARLAout__act_pitch_angle) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_pitch_angle")));
    M(CARLAout__act_roll_angle) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_roll_angle")));
    M(CARLAout__act_yaw_rate) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_yaw_rate")));
    M(CARLAout__act_throttle) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_throttle")));
    M(CARLAout__act_brake) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_brake")));
    M(CARLAout__act_long_acceleration) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "act_long_acceleration")));

    M(CARLAout__mini_lidar_front_x) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "mini_lidar_front_x")));
    M(CARLAout__mini_lidar_front_y) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "mini_lidar_front_y")));
    M(CARLAout__park_coordinate_x) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "park_coordinate_x")));
    M(CARLAout__park_coordinate_y) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "park_coordinate_y")));
    M(CARLAout__park_coordinate_z) = PyFloat_AsDouble(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "park_coordinate_z")));

    M(CARLAout__DooropenStatus_FL) = _PyLong_AsInt(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "Door_FL")));
    M(CARLAout__DooropenStatus_FR) = _PyLong_AsInt(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "Door_FR")));
    M(CARLAout__DooropenStatus_RL) = _PyLong_AsInt(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "Door_RL")));
    M(CARLAout__DooropenStatus_RR) = _PyLong_AsInt(PyObject_CallObject(hndl_getSignalValues, Py_BuildValue("(s)", "Door_RR")));
    
    Py_DECREF(hndl_getSignalValues);

    PyGILState_Release(gstate);

    return OK;
}


#ifdef CLEAN_UP
Status cleanup(ModelInstance* comp) {
 
    UNUSED(comp);

    printf("\nPERFORMING CLEANUP ..\n");
    /*To-Do: clean up operations*/
    return OK;
}
#endif // CLEAN_UP


Status getFloat64(ModelInstance* comp, ValueReference vr, double values[], size_t nValues, size_t* index) {

    ASSERT_NVALUES(1);

    switch (vr) {
    case vr_CARLAout__act_speed:
        values[(*index)++] = M(CARLAout__act_speed);
        return OK;
    case vr_CARLAout__act_steering:
        values[(*index)++] = M(CARLAout__act_steering);
        return OK;
    case vr_CARLAout__act_pos_x:
        values[(*index)++] = M(CARLAout__act_pos_x);
        return OK;
    case vr_CARLAout__act_pos_y:
        values[(*index)++] = M(CARLAout__act_pos_y);
        return OK;
    case vr_CARLAout__act_yaw_angle:
        values[(*index)++] = M(CARLAout__act_yaw_angle);
        return OK;
    case vr_CARLAout__act_lat_acceleration:
        values[(*index)++] = M(CARLAout__act_lat_acceleration);
        return OK;
    case vr_CARLAout__current_speed_limit:
        values[(*index)++] = M(CARLAout__current_speed_limit);
        return OK;
    case vr_CARLAout__act_pos_z:
        values[(*index)++] = M(CARLAout__act_pos_z);
        return OK;
    case vr_CARLAout__act_pitch_angle:
        values[(*index)++] = M(CARLAout__act_pitch_angle);
        return OK;
    case vr_CARLAout__act_roll_angle:
        values[(*index)++] = M(CARLAout__act_roll_angle);
        return OK;
    case vr_CARLAout__act_yaw_rate:
        values[(*index)++] = M(CARLAout__act_yaw_rate);
        return OK;
    case vr_CARLAout__act_throttle:
        values[(*index)++] = M(CARLAout__act_throttle);
        return OK;
    case vr_CARLAout__act_brake:
        values[(*index)++] = M(CARLAout__act_brake);
        return OK;
    case vr_CARLAout__act_long_acceleration:
        values[(*index)++] = M(CARLAout__act_long_acceleration);
        return OK;
    case vr_CARLAout__mini_lidar_front_x:
        values[(*index)++] = M(CARLAout__mini_lidar_front_x);
        return OK;
    case vr_CARLAout__mini_lidar_front_y:
        values[(*index)++] = M(CARLAout__mini_lidar_front_y);
        return OK;
    case vr_CARLAout__park_coordinate_x:
        values[(*index)++] = M(CARLAout__park_coordinate_x);
        return OK;
    case vr_CARLAout__park_coordinate_y:
        values[(*index)++] = M(CARLAout__park_coordinate_y);
        return OK;
    case vr_CARLAout__park_coordinate_z:
        values[(*index)++] = M(CARLAout__park_coordinate_z);
        return OK;
    default:
        logError(comp, "Get Float64 is not allowed for value reference %u.", vr); 
        return Error;
    }
}


Status setFloat64(ModelInstance* comp, ValueReference vr, const double values[], size_t nValues, size_t* index) {

    ASSERT_NVALUES(1);

    switch (vr) {
    case vr_CARLAin__desired_speed:
        M(CARLAin__desired_speed) = values[(*index)++];
        return OK;
    case vr_CARLAin__desired_steering:
        M(CARLAin__desired_steering) = values[(*index)++];
        return OK;
    case vr_CARLAin__desired_brake:
        M(CARLAin__desired_brake) = values[(*index)++];
        return OK;
    default:
        logError(comp, "Set Float64 is not allowed for value reference %u.", vr);
        return Error;
    }
}


Status setInt32(ModelInstance* comp, ValueReference vr, const int32_t values[], size_t nValues, size_t* index) {
    ASSERT_NVALUES(1);

    switch (vr) {
    case vr_CARLAin__toggle_display:
        M(CARLAin__toggle_display) = values[(*index)++];
        
        /*  toggling Pygame display to show sensor recordings */
        
        PyGILState_STATE gstate = PyGILState_Ensure();
        PyObject* display_mode = Py_BuildValue("(i)", M(CARLAin__toggle_display));
        PyObject_SetAttrString(mod_handle,"disp_mode",PyTuple_GetItem(display_mode, 0));
        Py_DecRef(display_mode);
        PyGILState_Release(gstate);
        
        return OK;
    case vr_CARLAin__operation_mode:
        M(CARLAin__operation_mode) = values[(*index)++];

        /*  Setting Opeartion Mode  */
        
        PyGILState_STATE gstate0 = PyGILState_Ensure();
        PyObject* sw_mode = Py_BuildValue("(i)", M(CARLAin__operation_mode));
        PyObject_SetAttrString(mod_handle,"op_mode",PyTuple_GetItem(sw_mode, 0));
        Py_DecRef(sw_mode);
        PyGILState_Release(gstate0);       
        
        return OK;
    case vr_CARLAin__toggle_view:
        M(CARLAin__toggle_view) = values[(*index)++];

        /*  toggling spectator view  */
        PyGILState_STATE gstate1 = PyGILState_Ensure();
        PyObject* view_mode = Py_BuildValue("(i)", M(CARLAin__toggle_view));
        PyObject_SetAttrString(mod_handle,"select_view",PyTuple_GetItem(view_mode, 0));
        Py_DecRef(view_mode);
        PyGILState_Release(gstate1);        
        
        return OK;
    case vr_CARLAin__toggle_special_lights:
        M(CARLAin__toggle_special_lights) = values[(*index)++];
        return OK;
    case vr_CARLAin__toggle_buzzer:
        M(CARLAin__toggle_buzzer) = values[(*index)++];
        return OK;
    case vr_CARLAin__reset_scene:
        M(CARLAin__reset_scene) = values[(*index)++];

        if (M(CARLAin__reset_scene) != resetScenario && M(CARLAin__reset_scene) == 1) {         

        resetScenario = M(CARLAin__reset_scene);
        
        /* RESETTING SCENARIO */
        PyGILState_STATE gstate2 = PyGILState_Ensure();

        PyObject* hndl_resetScene = PyObject_GetAttrString(mod_handle, "reset_scenario");

        /* setting value for scenario variable */
        PyObject* sim_scenario = Py_BuildValue("(i)", M(CARLAin__scenario));
        PyObject_SetAttrString(mod_handle,"scenario",PyTuple_GetItem(sim_scenario, 0));
        Py_DecRef(sim_scenario);

        PyObject* newScene = Py_BuildValue("(i)", M(CARLAin__scenario));
        PyObject_CallObject(hndl_resetScene, newScene);
        
        Py_DecRef(hndl_resetScene);
        Py_DecRef(newScene);

        PyGILState_Release(gstate2);
        } 
        else {
            resetScenario = M(CARLAin__reset_scene);
        }

        return OK;
    case vr_CARLAin__scenario:
        M(CARLAin__scenario) = values[(*index)++];
        
        /*
        // upadint value of global variable 'scenario' will be done when reset button is pressed from softcar
        PyGILState_STATE gstate3 = PyGILState_Ensure();
        PyObject* sim_scenario = Py_BuildValue("(i)", M(CARLAin__scenario));
        PyObject_SetAttrString(mod_handle,"scenario",PyTuple_GetItem(sim_scenario, 0));
        */


        
        return OK;
    case vr_CARLAin__auto_pilot:
        M(CARLAin__auto_pilot) = values[(*index)++];
        
        /* Enabling/Disabling Auto-Pilot */
        PyGILState_STATE gstate4 = PyGILState_Ensure();
        PyObject* autopilot = Py_BuildValue("(i)", M(CARLAin__auto_pilot));
        PyObject_SetAttrString(mod_handle,"auto_pilot",PyTuple_GetItem(autopilot, 0));

        Py_DecRef(autopilot);
        PyGILState_Release(gstate4);
        
        return OK;
    case vr_CARLAin__weather:
        M(CARLAin__weather) = values[(*index)++];
        
        /* Changing weather of CARLA world */
        PyGILState_STATE gstate5 = PyGILState_Ensure();
        PyObject* weather = Py_BuildValue("(i)", M(CARLAin__weather));
        PyObject* hndl_changeWeather = PyObject_GetAttrString(mod_handle, "change_weather");
        PyObject_CallObject(hndl_changeWeather, weather);

        Py_DecRef(weather);
        Py_DecRef(hndl_changeWeather);
        PyGILState_Release(gstate5);
        
        return OK;
    /* Input variables for display of truck status Msg*/
    case vr_CARLAin__DisplayColor_r:
        M(CARLAin__DisplayColor_r) = values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayColor_g:
        M(CARLAin__DisplayColor_g) = values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayColor_b:
        M(CARLAin__DisplayColor_b) = values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char01:
        M(CARLAin__DisplayText_char01) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char02:
        M(CARLAin__DisplayText_char02) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char03:
        M(CARLAin__DisplayText_char03) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char04:
        M(CARLAin__DisplayText_char04) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char05:
        M(CARLAin__DisplayText_char05) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char06:
        M(CARLAin__DisplayText_char06) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char07:
        M(CARLAin__DisplayText_char07) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char08:
        M(CARLAin__DisplayText_char08) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char09:
        M(CARLAin__DisplayText_char09) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char10:
        M(CARLAin__DisplayText_char10) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char11:
        M(CARLAin__DisplayText_char11) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char12:
        M(CARLAin__DisplayText_char12) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char13:
        M(CARLAin__DisplayText_char13) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char14:
        M(CARLAin__DisplayText_char14) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char15:
        M(CARLAin__DisplayText_char15) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;
    case vr_CARLAin__DisplayText_char16:
        M(CARLAin__DisplayText_char16) = values[(*index)] == 0 ? values[(*index)++]+32 : values[(*index)++];
        return OK;

    case vr_CARLAin__DooropenStatus_FL:
        M(CARLAin__DooropenStatus_FL) = values[(*index)++];
        
        /*  toggling Pygame display to show sensor recordings */
        
        PyGILState_STATE gstateFL = PyGILState_Ensure();
        PyObject* FL_Status = Py_BuildValue("(i)", M(CARLAin__DooropenStatus_FL));
        PyObject_SetAttrString(mod_handle,"Door_FL",PyTuple_GetItem(FL_Status, 0));
        Py_DecRef(FL_Status);
        PyGILState_Release(gstateFL);
        
        return OK;
    
    case vr_CARLAin__DooropenStatus_FR:
        M(CARLAin__DooropenStatus_FR) = values[(*index)++];
        
        /*  toggling Pygame display to show sensor recordings */
        
        PyGILState_STATE gstateFR = PyGILState_Ensure();
        PyObject* FR_Status = Py_BuildValue("(i)", M(CARLAin__DooropenStatus_FR));
        PyObject_SetAttrString(mod_handle,"Door_FR",PyTuple_GetItem(FR_Status, 0));
        Py_DecRef(FR_Status);
        PyGILState_Release(gstateFR);
        
        return OK;

    case vr_CARLAin__DooropenStatus_RL:
        M(CARLAin__DooropenStatus_RL) = values[(*index)++];
        
        /*  toggling Pygame display to show sensor recordings */
        
        PyGILState_STATE gstateRL = PyGILState_Ensure();
        PyObject* RL_Status = Py_BuildValue("(i)", M(CARLAin__DooropenStatus_RL));
        PyObject_SetAttrString(mod_handle,"Door_RL",PyTuple_GetItem(RL_Status, 0));
        Py_DecRef(RL_Status);
        PyGILState_Release(gstateRL);
        
        return OK;

    case vr_CARLAin__DooropenStatus_RR:
        M(CARLAin__DooropenStatus_RR) = values[(*index)++];
        
        /*  toggling Pygame display to show sensor recordings */
        
        PyGILState_STATE gstateRR = PyGILState_Ensure();
        PyObject* RR_Status = Py_BuildValue("(i)", M(CARLAin__DooropenStatus_RR));
        PyObject_SetAttrString(mod_handle,"Door_RR",PyTuple_GetItem(RR_Status, 0));
        Py_DecRef(RR_Status);
        PyGILState_Release(gstateRR);
        
        return OK;

    case vr_CARLAin__Headlight_Lowbeam:
        M(CARLAin__Headlight_Lowbeam) = values[(*index)++];
        
        /*  toggling Pygame display to show sensor recordings */
        
        PyGILState_STATE gstateHLLowbeam = PyGILState_Ensure();
        PyObject* RR_Status_HLLowbeam = Py_BuildValue("(i)", M(CARLAin__Headlight_Lowbeam));
        PyObject_SetAttrString(mod_handle,"Headlight_Lowbeam",PyTuple_GetItem(RR_Status_HLLowbeam, 0));
        Py_DecRef(RR_Status_HLLowbeam);
        PyGILState_Release(gstateHLLowbeam);
        
        return OK;

    default:
        logError(comp, "Set Integer is not allowed for value reference %u.", vr);
        return Error;
    }
}

Status getInt32(ModelInstance* comp, ValueReference vr, int32_t values[], size_t nValues, size_t *index) 
{
    ASSERT_NVALUES(1);

    switch (vr) 
    {
    case vr_CARLAout__DooropenStatus_FL:
        values[(*index)++] = M(CARLAout__DooropenStatus_FL);
        return OK;

    case vr_CARLAout__DooropenStatus_FR:
        values[(*index)++] = M(CARLAout__DooropenStatus_FR);
        return OK;

    case vr_CARLAout__DooropenStatus_RL:
        values[(*index)++] = M(CARLAout__DooropenStatus_RL);
        return OK;

    case vr_CARLAout__DooropenStatus_RR:
        values[(*index)++] = M(CARLAout__DooropenStatus_RR);
        return OK;

    default:
        logError(comp, "Get Float64 is not allowed for value reference %u.", vr); 
        return Error;
    }
}
void eventUpdate(ModelInstance *comp) {

    /*  acquiring GIL lock to avoid segmentation faults  */
    PyGILState_STATE gstate = PyGILState_Ensure();

    
    /*  Applying control values to vehicle  */
    PyObject* hndl_applCtrlValues = PyObject_GetAttrString(mod_handle, "apply_vehicle_control");
    PyObject* control_values;

    control_values = Py_BuildValue("dddii", M(CARLAin__desired_speed), M(CARLAin__desired_steering), M(CARLAin__desired_brake), M(CARLAin__toggle_special_lights), M(CARLAin__toggle_buzzer));
    
    PyObject* sim_status = PyObject_CallObject(hndl_applCtrlValues, control_values);
    
    #ifdef pipeForLidarPC
    /* fetching LIDAR point cloud data  */
    PyObject* temp_pLidarPointCloud = PyObject_GetAttrString(mod_handle, "pLidarPointCloud");
    
    /* storing point cloud data as array*/
    double arr_pLidarPointCloud[BUFSIZE];

    if (PyList_Check(temp_pLidarPointCloud))
    {
        
        for (int i = 0; i < BUFSIZE; i++)
        {
            if (i < PyList_Size(temp_pLidarPointCloud))
            {
                PyObject* list_element = PyList_GetItem(temp_pLidarPointCloud, i);
                arr_pLidarPointCloud[i] = PyFloat_AsDouble(list_element)*0.125;     // divided by 8 as CARLA env is 8:1 of real env
            }

            if (i >= PyList_Size(temp_pLidarPointCloud) && i < BUFSIZE)
            {
                arr_pLidarPointCloud[i] = 0.0;
            }
            
        }
    } else {
        // printf("\n !! get not accomplihed as temp_pLidarPointCloud is not a list");
        printf("\nError in fetching Lidar point cloud. Terminating simulation.");
        comp->terminateSimulation               = true;
        comp->nextEventTimeDefined              = false;
        return;
    }

    /* writing LIDAR data to pipe */
    ConnectNamedPipe(pipe, NULL);
    /* disconnecting the pipe if an already connected client had ended.
    in next eventUpdate() iteration, ConnectNamedPipe in line 510 will make the pipe handle available for new client connection*/
    if (GetLastError() == 232)
    {
        DisconnectNamedPipe(pipe);
    }
    DWORD numWritten;
    WriteFile(pipe, arr_pLidarPointCloud, BUFSIZE*sizeof(double), &numWritten, NULL);

    Py_DecRef(temp_pLidarPointCloud);
    #endif

    /* CAMERA IMAGE TRANSFER */
    #ifdef pipeForCamera    
    /* fetching grey image array  */
    PyObject* temp_greyimgarray = PyObject_GetAttrString(mod_handle, "rgb_array");
    
    /* storing img in C array*/
    int arr_greyImg[BUFSIZE_FRONTCAMERA];

    if (PyList_Check(temp_greyimgarray))
    {
        for (int j = 0; j < PyList_Size(temp_greyimgarray); j++)
        {
            PyObject* lelement = PyList_GetItem(temp_greyimgarray, j);
            arr_greyImg[j] = _PyLong_AsInt(lelement);
        }
    } else {
        // printf("\n !! get not accomplihed as temp_greyimgarray is not a list");
        printf("\nError in fetching camera Image. Terminating simulation.");
        comp->terminateSimulation               = true;
        comp->nextEventTimeDefined              = false;
        return;
    }
    /* writing camera data to pipe_FRONTCAMERA*/
    ConnectNamedPipe(pipe_FrontCamera, NULL);
    DWORD numOfBytesWritten;
    WriteFile(pipe_FrontCamera, arr_greyImg, BUFSIZE_FRONTCAMERA*sizeof(int), &numOfBytesWritten, NULL);

    Py_DecRef(temp_greyimgarray);
    #endif

    /* function call to display text */
    // displayMessage('Hi Welcome to Hackathon', 0, 0, 255)
    PyObject* hndl_displayMessage = PyObject_GetAttrString(mod_handle, "displayMessage");
    PyObject* displayArgs;

    char message[17];
    sprintf(message, "%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", (char)M(CARLAin__DisplayText_char01), (char)M(CARLAin__DisplayText_char02), (char)M(CARLAin__DisplayText_char03), M(CARLAin__DisplayText_char04), (char)M(CARLAin__DisplayText_char05), (char)M(CARLAin__DisplayText_char06), (char)M(CARLAin__DisplayText_char07), (char)M(CARLAin__DisplayText_char08), M(CARLAin__DisplayText_char09), (char)M(CARLAin__DisplayText_char10), (char)M(CARLAin__DisplayText_char11), (char)M(CARLAin__DisplayText_char12), (char)M(CARLAin__DisplayText_char13), M(CARLAin__DisplayText_char14), (char)M(CARLAin__DisplayText_char15), (char)M(CARLAin__DisplayText_char16));

    // strcat()
    displayArgs = Py_BuildValue("siii", message, M(CARLAin__DisplayColor_r), M(CARLAin__DisplayColor_g), M(CARLAin__DisplayColor_b));
    PyObject_CallObject(hndl_displayMessage, displayArgs);

    comp->valuesOfContinuousStatesChanged   = false;
    comp->nominalsOfContinuousStatesChanged = false;

    if (_PyLong_AsInt(sim_status) == 1) {
        #ifdef pipeForLidarPC
        DisconnectNamedPipe(pipe);
        CloseHandle(pipe);
        #endif

        #ifdef pipeForCamera
        DisconnectNamedPipe(pipe_FrontCamera);
        CloseHandle(pipe_FrontCamera);
        #endif
        
        comp->terminateSimulation               = true;
        comp->nextEventTimeDefined              = false;
    } else {
        comp->terminateSimulation               = false;
        comp->nextEventTimeDefined              = true;
    }

     PyGILState_Release(gstate);

}
